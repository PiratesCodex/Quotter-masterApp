<img align="left" src="https://raw.githubusercontent.com/NazeemNato/Flutter-Random-Quote-App/master/android/app/src/main/res/mipmap-mdpi/launcher_icon.png" alt=""> 

# QuotApp

*Quotapp* provides you approx 5000+  Motivational & Inspirational quotes by famous authors, celebrities.
you can share the quotes with your friends by tap on copy button

- Written flutter. 
- open source

[![Download Latest version ](http://3.bp.blogspot.com/-WGQbu1DZg6A/VNRknAPOe8I/AAAAAAAAFEg/h5kJ30cCMBw/s1600/download%2Bapk.png)](https://github.com/NazeemNato/Flutter-Random-Quote-App/blob/master/apk/QuotApp%20V1.0.0.apk?raw=true)

# Current features
- Randomly created a quote while opening app
- Copy to clipboard avilable
- Offline work

# Next updat(V1.0.1)
- Daily quotes notification on 5 am
- Social media share
- author category
- save your quotes


# ScreenShots

<img align="left" src="https://raw.githubusercontent.com/NazeemNato/Flutter-Random-Quote-App/master/screenshot/1.png" width="225" height="400" alt="">
<img align="left" src="https://raw.githubusercontent.com/NazeemNato/Flutter-Random-Quote-App/master/screenshot/2.png" width="225" height="400" alt="">


